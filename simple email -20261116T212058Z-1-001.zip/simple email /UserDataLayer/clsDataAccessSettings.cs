﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDataLayer
{

        static class clsDataAccessSettings
        {
            public static string ConnectionString = "Server=.;Database=UsersDB;User Id=sa;Password=123456;";


        }
    
}
