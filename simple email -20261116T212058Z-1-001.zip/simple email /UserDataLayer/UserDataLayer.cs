﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace UserDataLayer
{
    public class clsUserDataLayer
    {
       public static bool IsValidUser(string UserName,string Password)
        {   
            bool IsValid = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT UserName FROM Users WHERE UserName = @UserName AND Password = @Password";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@UserName", UserName);
            command.Parameters.AddWithValue("@Password", Password);

            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                IsValid = (result != null);
            }
            catch (Exception ex)
            {
               
                IsValid = false;
            }

            finally
            {
                connection.Close();
            }

            return IsValid;

        }



    }
}
