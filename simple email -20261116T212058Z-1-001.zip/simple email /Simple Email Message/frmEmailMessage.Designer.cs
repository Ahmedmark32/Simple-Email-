﻿namespace Simple_Email_Message
{
    partial class frmEmailMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.lblEmailCheck = new System.Windows.Forms.Label();
            this.btnLTR = new System.Windows.Forms.Button();
            this.btnRTL = new System.Windows.Forms.Button();
            this.btnBLD = new System.Windows.Forms.Button();
            this.btnREG = new System.Windows.Forms.Button();
            this.btnITALIC = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnCENTER = new System.Windows.Forms.Button();
            this.btnLEFT = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSend = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblCheckSubject = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lblUser = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtTo
            // 
            this.txtTo.Location = new System.Drawing.Point(86, 47);
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new System.Drawing.Size(212, 22);
            this.txtTo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(38, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "To:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(20, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Subject:";
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(110, 98);
            this.txtSubject.Multiline = true;
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(217, 25);
            this.txtSubject.TabIndex = 2;
            // 
            // lblEmailCheck
            // 
            this.lblEmailCheck.AutoSize = true;
            this.lblEmailCheck.BackColor = System.Drawing.Color.Red;
            this.lblEmailCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblEmailCheck.Location = new System.Drawing.Point(333, 44);
            this.lblEmailCheck.Name = "lblEmailCheck";
            this.lblEmailCheck.Size = new System.Drawing.Size(0, 25);
            this.lblEmailCheck.TabIndex = 4;
            // 
            // btnLTR
            // 
            this.btnLTR.BackColor = System.Drawing.SystemColors.Info;
            this.btnLTR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnLTR.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnLTR.Location = new System.Drawing.Point(25, 169);
            this.btnLTR.Name = "btnLTR";
            this.btnLTR.Size = new System.Drawing.Size(88, 36);
            this.btnLTR.TabIndex = 5;
            this.btnLTR.Text = "LTR";
            this.btnLTR.UseVisualStyleBackColor = false;
            this.btnLTR.Click += new System.EventHandler(this.btnLTR_Click);
            // 
            // btnRTL
            // 
            this.btnRTL.BackColor = System.Drawing.SystemColors.Window;
            this.btnRTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnRTL.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnRTL.Location = new System.Drawing.Point(134, 169);
            this.btnRTL.Name = "btnRTL";
            this.btnRTL.Size = new System.Drawing.Size(88, 36);
            this.btnRTL.TabIndex = 6;
            this.btnRTL.Text = "RTL";
            this.btnRTL.UseVisualStyleBackColor = false;
            this.btnRTL.Click += new System.EventHandler(this.btnRTL_Click);
            // 
            // btnBLD
            // 
            this.btnBLD.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnBLD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnBLD.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnBLD.Location = new System.Drawing.Point(308, 169);
            this.btnBLD.Name = "btnBLD";
            this.btnBLD.Size = new System.Drawing.Size(88, 36);
            this.btnBLD.TabIndex = 7;
            this.btnBLD.Text = "BLD";
            this.btnBLD.UseVisualStyleBackColor = false;
            this.btnBLD.Click += new System.EventHandler(this.btnBLD_Click);
            // 
            // btnREG
            // 
            this.btnREG.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnREG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnREG.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnREG.Location = new System.Drawing.Point(417, 169);
            this.btnREG.Name = "btnREG";
            this.btnREG.Size = new System.Drawing.Size(88, 36);
            this.btnREG.TabIndex = 8;
            this.btnREG.Text = "REG";
            this.btnREG.UseVisualStyleBackColor = false;
            this.btnREG.Click += new System.EventHandler(this.btnREG_Click);
            // 
            // btnITALIC
            // 
            this.btnITALIC.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnITALIC.FlatAppearance.BorderSize = 0;
            this.btnITALIC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnITALIC.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnITALIC.Location = new System.Drawing.Point(526, 169);
            this.btnITALIC.Name = "btnITALIC";
            this.btnITALIC.Size = new System.Drawing.Size(88, 36);
            this.btnITALIC.TabIndex = 9;
            this.btnITALIC.Text = "ITALIC";
            this.btnITALIC.UseVisualStyleBackColor = false;
            this.btnITALIC.Click += new System.EventHandler(this.btnITALIC_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.LightCoral;
            this.btnRight.FlatAppearance.BorderSize = 0;
            this.btnRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnRight.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnRight.Location = new System.Drawing.Point(916, 169);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(88, 36);
            this.btnRight.TabIndex = 12;
            this.btnRight.Text = "RIGHT";
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnCENTER
            // 
            this.btnCENTER.BackColor = System.Drawing.Color.LightCoral;
            this.btnCENTER.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCENTER.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnCENTER.Location = new System.Drawing.Point(807, 169);
            this.btnCENTER.Name = "btnCENTER";
            this.btnCENTER.Size = new System.Drawing.Size(88, 36);
            this.btnCENTER.TabIndex = 11;
            this.btnCENTER.Text = "CENTER";
            this.btnCENTER.UseVisualStyleBackColor = false;
            this.btnCENTER.Click += new System.EventHandler(this.btnCENTER_Click);
            // 
            // btnLEFT
            // 
            this.btnLEFT.BackColor = System.Drawing.Color.LightCoral;
            this.btnLEFT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnLEFT.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnLEFT.Location = new System.Drawing.Point(698, 169);
            this.btnLEFT.Name = "btnLEFT";
            this.btnLEFT.Size = new System.Drawing.Size(88, 36);
            this.btnLEFT.TabIndex = 10;
            this.btnLEFT.Text = "LEFT";
            this.btnLEFT.UseVisualStyleBackColor = false;
            this.btnLEFT.Click += new System.EventHandler(this.btnLEFT_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(73, 268);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(822, 266);
            this.txtMessage.TabIndex = 13;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnExit.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnExit.Location = new System.Drawing.Point(957, 559);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 36);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSend.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnSend.Location = new System.Drawing.Point(848, 559);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(88, 36);
            this.btnSend.TabIndex = 14;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Linen;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(408, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 29);
            this.label3.TabIndex = 16;
            this.label3.Text = "Main Subject\r\n";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dateTimePicker1.Location = new System.Drawing.Point(807, 23);
            this.dateTimePicker1.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 17;
            // 
            // lblCheckSubject
            // 
            this.lblCheckSubject.AutoSize = true;
            this.lblCheckSubject.BackColor = System.Drawing.Color.Red;
            this.lblCheckSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblCheckSubject.Location = new System.Drawing.Point(333, 94);
            this.lblCheckSubject.Name = "lblCheckSubject";
            this.lblCheckSubject.Size = new System.Drawing.Size(0, 25);
            this.lblCheckSubject.TabIndex = 18;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblUser.ForeColor = System.Drawing.Color.Lime;
            this.lblUser.Location = new System.Drawing.Point(12, 569);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 29);
            this.lblUser.TabIndex = 19;
            // 
            // frmEmailMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1046, 607);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.lblCheckSubject);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnCENTER);
            this.Controls.Add(this.btnLEFT);
            this.Controls.Add(this.btnITALIC);
            this.Controls.Add(this.btnREG);
            this.Controls.Add(this.btnBLD);
            this.Controls.Add(this.btnRTL);
            this.Controls.Add(this.btnLTR);
            this.Controls.Add(this.lblEmailCheck);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSubject);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTo);
            this.Name = "frmEmailMessage";
            this.Text = "Send Email";
            this.Load += new System.EventHandler(this.frmEmailMessage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label lblEmailCheck;
        private System.Windows.Forms.Button btnLTR;
        private System.Windows.Forms.Button btnRTL;
        private System.Windows.Forms.Button btnBLD;
        private System.Windows.Forms.Button btnREG;
        private System.Windows.Forms.Button btnITALIC;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnCENTER;
        private System.Windows.Forms.Button btnLEFT;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblCheckSubject;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label lblUser;
    }
}

