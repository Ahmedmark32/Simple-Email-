﻿using LogIN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simple_Email_Message
{
    public partial class frmEmailMessage : Form
    {
       private static string _userName;
        public static void  SetUserName(string userName)
        {
             _userName = userName;
        }

        public frmEmailMessage()
        {
            InitializeComponent();

        }

        private void SaveFileAsTxt(string Message)
        {   
          
            saveFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            saveFileDialog1.Title = "Save Email Message As";
            saveFileDialog1.InitialDirectory = @"C:\";
            saveFileDialog1.DefaultExt = "txt";
            

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    System.IO.File.WriteAllText(saveFileDialog1.FileName, Message);
                    MessageBox.Show("Email message saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error saving file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void frmEmailMessage_Load(object sender, EventArgs e)
        {   
              txtTo.Font = new Font("Arial", 10, FontStyle.Regular);
              txtSubject.Font = new Font("Arial", 10, FontStyle.Regular);
              txtMessage.Font = new Font("Arial", 12, FontStyle.Regular);
              lblUser.Text = "Logged in as: " + _userName;
              
              
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
              
           if (MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation"
               , MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTo.Text) || 
                string.IsNullOrWhiteSpace(txtSubject.Text) ||
                string.IsNullOrWhiteSpace(txtMessage.Text))
            {  
                MessageBox.Show("Please fill in all fields before sending the email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblEmailCheck.Text = "Please fill in all fields before sending the email.";
                lblCheckSubject.Text = "Please fill in all fields before sending the email.";
                return;
            }

            if (!txtTo.Text.EndsWith("@gmail.com",StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Please enter a valid Gmail address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblEmailCheck.Text = "Please enter a valid Gmail address.";
                return;
            }

            if ( MessageBox.Show("Email will be sent. Do you want to continue?", "", MessageBoxButtons.YesNo,
                MessageBoxIcon.Information) == DialogResult.Yes)
            {

                SaveFileAsTxt(txtMessage.Text);

            }
        }

        private void btnLTR_Click(object sender, EventArgs e)
        {
            txtMessage.RightToLeft = RightToLeft.No;
        }

        private void btnRTL_Click(object sender, EventArgs e)
        {
            txtMessage.RightToLeft = RightToLeft.Yes;
        }

        private void btnBLD_Click(object sender, EventArgs e)
        {
            txtMessage.Font = new Font(txtMessage.Font, FontStyle.Bold);
        }

        private void btnREG_Click(object sender, EventArgs e)
        {
            txtMessage.Font = new Font(txtMessage.Font, FontStyle.Regular);
        }

        private void btnITALIC_Click(object sender, EventArgs e)
        {
            txtMessage.Font = new Font(txtMessage.Font, FontStyle.Italic);
        }

        private void btnLEFT_Click(object sender, EventArgs e)
        {
            txtMessage.TextAlign = HorizontalAlignment.Left;
        }

        private void btnCENTER_Click(object sender, EventArgs e)
        {
            txtMessage.TextAlign = HorizontalAlignment.Center;
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            txtMessage.TextAlign = HorizontalAlignment.Right;
        }
    }
}
