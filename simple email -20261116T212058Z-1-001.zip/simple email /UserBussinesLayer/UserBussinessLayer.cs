﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDataLayer;

namespace UserBussinessLayer
{
    public class clsUserBussinessLayer
    {

        public bool FindUserByUserNameAndPassword(string userName, string password)
        {
            
             return clsUserDataLayer.IsValidUser(userName, password);
           
         
        }

    }
}
